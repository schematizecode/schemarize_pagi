<?php
/*
Plugin Name: Schematize Pagi
Plugin URI: http://schematize.com.br/
Description: A partir da paginação nativa dentro de posts do wordpress, você poderá adicionar botões para deixar sua paginação mais agradável e intuitiva.
Version: 1.0.0
Author: Schematize
Author URI: http://schematize.com.br/
*/
add_action( 'admin_menu', 'register_my_custom_menu_page' );

function register_my_custom_menu_page() {
  add_menu_page(
    'Schematize Pagi',
    'Schematize Pagi',
    'manage_options',
    'custom-menu-page',
    'display_custom_menu_page',
    'dashicons-arrow-right-alt',
    6
  );
}

function display_custom_menu_page() {
  echo '<h1>Menu de personalização de botões</h1>';
 function update_text_field($field) {
  if ( isset( $_POST['save_text'])) {
    update_option( $field, sanitize_text_field( $_POST[$field] ) );
  }
  return get_option( $field );
}
$preenchimento = update_text_field('preenchimento');
$preenchimentoh = update_text_field('preenchimentoh');
$textcolor = update_text_field('textcolor');
$bgcolor = update_text_field('bgcolor');
$bradius = update_text_field('bradius');
$fonts = update_text_field('fonts');
$border_style = update_text_field('border_style');
$txtnxt = update_text_field('txtnxt');
$prvtxt = update_text_field('prvtxt');
	
	//SALVA O BOTÃO ESTILIZADO 
	if ( isset( $_POST['save_text'])) {
  update_option( 'button_style', sanitize_text_field( 'background-color: ' . $_POST['bgcolor'] . '; padding-left: ' . $_POST['preenchimento'] . 'px; padding-right: ' . $_POST['preenchimento'] . 'px; color: ' . $_POST['textcolor'] . '; padding-top: ' . $_POST['preenchimentoh'] . 'px; padding-bottom: ' . $_POST['preenchimentoh'] . 'px;'  . 'border-radius: ' . $_POST['bradius'] . 'px;' . 'font-size: ' . $_POST['fonts'] . 'px;') );
}
$button_style = get_option( 'button_style' );
	
  
  echo '<form action="" method="post">
  		<div class="contn">
		<label>Texto "Próxima Página": </label><input type="text" name="txtnxt" value="' . esc_attr($txtnxt) . '" id="nxtpg"><br>
		<label>Texto "Página Anterior": </label><input type="text" name="prvtxt" value="' . esc_attr($prvtxt) . '" id="prvpg"><br>
  		<label>Preenchimento Lateral: </label><input type="number" name="preenchimento" value="' . esc_attr( $preenchimento ) . '" id="prl"><br>
		<label>Preenchimento Vertical: </label><input type="number" name="preenchimentoh" value="' . esc_attr( $preenchimentoh ) . '" id="prh"><br>
		<label>Arredondar bordas: </label><input type="number" name="bradius" value="' . esc_attr( $bradius ) . '" id="bradius"><br>
		<label>Tamanho da fonte: </label><input type="number" name="fonts" value="' . esc_attr( $fonts ) . '" id="fonts"><br>
		<label>Cor do Texto: </label><input type="color" name="textcolor" value="' . esc_attr( $textcolor ) . '" id="txtcolor"><br>
		<label>Cor de Fundo: </label><input type="color" name="bgcolor" value="' . esc_attr( $bgcolor ) . '" id="bgcolor"><br>
		<input type="submit" name="save_text" value="Salvar" id="saves">
		<hr>
		<input type="button" value="' . esc_attr( $txtnxt ) . '" style="' . esc_attr( $button_style ) . '" id="nxt2" name="nxt2" class="btback">
		</div>
		</form>';
	echo '
	<script>
	document.getElementById("nxtpg").addEventListener("input", function() {
		document.getElementById("nxt2").value = this.value;
	  });
	  
	  document.getElementById("prvpg").addEventListener("input", function() {
		document.getElementById("prv2").value = this.value;
	  });
	  
	  document.getElementById("prl").addEventListener("input", function() {
		document.getElementById("nxt2").style.paddingLeft = this.value + "px";
		document.getElementById("prv2").style.paddingLeft = this.value + "px";
	  });
	  
	  document.getElementById("prh").addEventListener("input", function() {
		document.getElementById("nxt2").style.paddingTop = this.value + "px";
		document.getElementById("nxt2").style.paddingBottom = this.value + "px";
		document.getElementById("prv2").style.paddingTop = this.value + "px";
		document.getElementById("prv2").style.paddingBottom = this.value + "px";
	  });
	  
	  document.getElementById("bradius").addEventListener("input", function() {
		document.getElementById("nxt2").style.borderRadius = this.value + "px";
		document.getElementById("prv2").style.borderRadius = this.value + "px";
	  });
	  
	  document.getElementById("fonts").addEventListener("input", function() {
		document.getElementById("nxt2").style.fontSize = this.value + "px";
		document.getElementById("prv2").style.fontSize = this.value + "px";
	  });
	  
	  document.getElementById("txtcolor").addEventListener("input", function() {
		document.getElementById("nxt2").style.color = this.value;
		document.getElementById("prv2").style.color = this.value;
	  });
	  
	  document.getElementById("bgcolor").addEventListener("input", function() {
		document.getElementById("nxt2").style.backgroundColor = this.value;
		document.getElementById("prv2").style.backgroundColor = this.value;
	  });
	  document.getElementById("prl").addEventListener("input", function() {
		document.getElementById("nxt2").style.paddingRight = this.value + "px";
		document.getElementById("prv2").style.paddingRight = this.value + "px";
	  });
</script>
	';
	echo '
	<style>
		.btback {
			border: none;
		}
		#nxt {
			border: none;
			margin: 0 auto;
		}
		label {
			 display: inline-block;
   			 width: 150px;
		}
		.contn {
			line-height: 40px;
		}
	</style>
	';
}
add_filter( 'wp_link_pages_args', 'wpse_next_page_link_text' );
function wpse_next_page_link_text( $args ) {
	$prvtxt_e = get_option( 'prvtxt' );
	$txtnxt_e = get_option( 'txtnxt' );
	$button_style = get_option( 'button_style' );
    $args['next_or_number'] = 'next';
	$args['previouspagelink'] = __( '<input type="button" value="' . esc_attr( $prvtxt_e ) . '" style="' . esc_attr( $button_style ) . '" class="btfront">' );
    $args['nextpagelink'] = __( '<input type="button" value="' . esc_attr( $txtnxt_e ) . '" style="' . esc_attr( $button_style ) . '" class="btfront">
' );
    return $args;
}
function custom_css() {
  echo '<style>
    .page-links-title {
		display: none;
	}
	.page-links {
			text-align: center;
		}
		.btfront {
			border: none;
		}
  </style>';
}
add_action( 'wp_head', 'custom_css' );
?>